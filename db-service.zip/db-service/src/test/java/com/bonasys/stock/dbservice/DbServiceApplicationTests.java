package com.bonasys.stock.dbservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
